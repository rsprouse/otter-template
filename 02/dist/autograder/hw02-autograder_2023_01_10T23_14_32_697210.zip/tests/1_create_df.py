OK_FORMAT = True

test = {   'name': '1_create_df',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> try:\n'
                                               "...     assert((sortdf['fwd'] == df['fwd'].iloc[::-1]).all())\n"
                                               "...     assert((sortdf['rev'] == df['rev'].iloc[::-1]).all())\n"
                                               '... except AssertionError:\n'
                                               '...     print("sortdf is not properly sorted.")\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
