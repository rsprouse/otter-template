OK_FORMAT = True

test = {   'name': '2_create_2col_df',
    'points': 10,
    'suites': [   {   'cases': [   {'code': '>>> assert(type(df) == pd.core.frame.DataFrame)\n', 'hidden': False, 'locked': False},
                                   {'code': ">>> assert(set(df.columns) == set(['t1', 't2']))\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert((df['t1'] == [0.0, 0.1]).all())\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert((df['t2'] == [0.1, 0.2]).all())\n", 'hidden': False, 'locked': False},
                                   {'code': '>>> assert(len(df) == 2)\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
