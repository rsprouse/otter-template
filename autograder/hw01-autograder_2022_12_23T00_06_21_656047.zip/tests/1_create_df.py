OK_FORMAT = True

test = {   'name': '1_create_df',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> assert(type(empty) == pd.core.frame.DataFrame)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert(len(empty) == 0)\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
